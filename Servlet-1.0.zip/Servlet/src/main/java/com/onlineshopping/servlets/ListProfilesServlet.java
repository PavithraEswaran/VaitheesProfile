package com.onlineshopping.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.onlineshopping.daoImplementation.ProfileDaoImp;
import com.onlineshopping.entity.Profile;


@WebServlet("/ListProfilesServlet")
public class ListProfilesServlet extends HttpServlet {
	
	ProfileDaoImp ProfileDaoObj = new ProfileDaoImp();

	
	private static final long serialVersionUID = 1L;
 
    public ListProfilesServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		List<Profile> profileList = new ArrayList<Profile>();
		profileList=ProfileDaoObj.getAllProducts();
		request.setAttribute("lists", profileList);
		request.getRequestDispatcher("userlist.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
