package com.onlineshopping.entity;

import java.io.Serializable;

public class Profile implements Serializable {

	String pid;
	String name;
	String mNum;
	String email;
	String address;
	String pcode;
	boolean valid = false;
	
	public String getPid() {
		return pid;
	}

	public void setPid(String pid) {
		this.pid = pid;
	}


	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getmNum() {
		return mNum;
	}

	public void setmNum(String mNum) {
		if (mNum.length() == 10) {
			try {
				Long.parseLong(mNum);
				System.out.println("Valid Number");
				this.mNum = mNum;
			} catch (Exception e) {
				System.out.println("Not a valid number");
			}
		} else {
			System.out.println("Please, enter correct mobile number	");
		}
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPcode() {
		return pcode;
	}

	public void setPcode(String pcode) {
		if (pcode.length() < 8) {
			valid = false;
			System.out.println("Password must have at least 8 characters. Try again!");
		} else {
			for (int i = 0; i < pcode.length(); i++) {
				char c = pcode.charAt(i);
				if (('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z') || ('0' <= c && c <= '9')) {
					valid = true;
				} else {
					System.out.println("Only letter & digits are acceptable.  Try again!");
					valid = false;
					break;
				}
			}
		}
		if (valid == true) {
			this.pcode = pcode;
			System.out.println("Password accepted!!!");
		}
	}
}
