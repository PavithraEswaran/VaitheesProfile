package com.onlineshopping.daoImplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.onlineshopping.connectivity.DB;
import com.onlineshopping.dao.ProfileDao;
import com.onlineshopping.entity.Profile;

public class ProfileDaoImp implements ProfileDao {
	
	private static final Map<String, Profile> profileMap = new HashMap<String, Profile>();
	
	
	
	public boolean adminCheck(String name, String password)
	{
		if((name.equals("admin@virtusa.com")&&password.equals("1234")))
		{
			System.out.println(name+" "+password);
			return true;
		}
		else
			return false;
	}
	public void addProfile(String pid, String name, String mobileNumber, String email, String address, String password) {
		Profile profileObj = new Profile();
		profileObj.setPid(pid);
		profileObj.setName(name);
		profileObj.setmNum(mobileNumber);
		profileObj.setEmail(email);
		profileObj.setAddress(address);
		profileObj.setPcode(password);
		profileMap.put(profileObj.getPid(), profileObj);
		System.out.println(profileObj.getPid());
//		try{
//			Connection con=DB.getConnection();
//			PreparedStatement ps=con.prepareStatement("insert into [Sheet1$](name,mobileNumber,email,address,password) values(?,?,?,?,?)");
//			ps.setString(1,profileObj.getName());
//			ps.setString(2,profileObj.getmNum());
//			ps.setString(3,profileObj.getEmail());
//			ps.setString(4,profileObj.getAddress());
//			ps.setString(5,profileObj.getPcode());
//			ps.executeUpdate();
//			con.close();
//		}catch(Exception ex){System.out.println(ex);}
		
	}
	
	 public List<Profile> getAllProducts(){
			List<Profile> profileList = new ArrayList<Profile>();
			profileList.addAll(profileMap.values());
			for(Profile s:profileList)
			{
				System.out.println(s.getPid());
			}
			//System.out.println(profileList);
			return profileList;
		}


}
