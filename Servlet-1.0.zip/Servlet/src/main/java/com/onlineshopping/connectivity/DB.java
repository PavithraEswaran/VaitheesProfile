package com.onlineshopping.connectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DB {
	public static Connection getConnection() throws Exception {
		String driver = "sun.jdbc.odbc.JdbcOdbcDriver";
		String url = "jdbc:odbc:excelDB";
		String username = "";
		String password = "";
		Class.forName(driver);
		return DriverManager.getConnection(url, username, password);
	}

}
