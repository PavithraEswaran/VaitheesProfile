package com.onlineshopping.dao;

public interface ProfileDao {
	public boolean adminCheck(String name, String password);
	public void addProfile(String pid, String name, String mobileNumber, String email, String address, String password);
	

}
