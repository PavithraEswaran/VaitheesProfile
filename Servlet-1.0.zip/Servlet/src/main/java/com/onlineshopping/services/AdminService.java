package com.onlineshopping.services;

import java.util.ArrayList;
import java.util.List;


import com.onlineshopping.daoImplementation.ProfileDaoImp;
import com.onlineshopping.entity.Profile;

public class AdminService {
	ProfileDaoImp ProfileDaoObj = new ProfileDaoImp();
	
	public boolean adminValidation(String name, String password) {
		return ProfileDaoObj.adminCheck(name, password);
	}
	
	public void addProfile(String pid, String name, String mobileNumber, String email, String address, String password)
	{
		ProfileDaoObj.addProfile(pid, name, mobileNumber, email, address, password);
	}
	
}
